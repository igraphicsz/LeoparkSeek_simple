# 自动交易回测工具
## 简介
  这是一个整合自动化回测, 模拟盘与实盘交易的工具，用户可以通过配置各种参数来进行回测以及模拟交易与实盘交易。
# 配置文件
## 全局配置文件示例
```json
// 全局配置：config.json
{
  "license": "123456", // 准入许可，联系相关人获取
  "strategy": "macd",  // 策略名称(策略文件名)

  // 回测功能需要设置回测开始于结束时间
  "begin": "10/7/2025",
  "end": "11/7/2025",

  // 模拟盘与实盘交易功能需要设置交易账号, 密码与交易通道
  "account": "123456",
  "password": "123456",
  "channel_code": "123456"
}
```

## 策略配置文件示例
```yaml
# 策略配置：config下的 策略名称.yaml
NAME: 'Start1'      # 策略名称
MODULE: 'Strat1'    # 与策略名称一致
CLASS: 'Strat1'     # 策略文件的类名
INTERVAL: '1min'  # 回测间隔周期
PARAMETERS:       # 策略参数
macd_fast: 12
macd_slow: 26
macd_smoothing: 9

WATCHLIST: ['ao', 'rb', 'jm', 'm']  # 策略执行的期货商品代码
```

## 合约配置文件示例
```json
// contract_maps 下 策略名称.json
{
  // 期货商品代码：该商品交易合约代码，一一对应
  "ao": "ao2605",
  "rb": "rb2605",
  "jm": "jm2605",
  "m": "m2605"
}
```
# 策略文件
策略在strategies文件夹下编写，可参考示例策略代码

# 回测, 模拟盘或实盘交易

## 安装依赖
请使用 Python 3.11 的虚拟环境安装依赖并运行 LeopardSeek。
```bash
pip install http://www.popper-fintech.com/ls/leopardseek_core-1.0.0.tar.gz
```

## 执行
```bash
执行 Start_backtest.py  Main方法(回测)
执行 Start_virtual_trade.py  Main方法(模拟盘交易)
执行 Start_live_trade.py  Main方法(实盘交易)
```
