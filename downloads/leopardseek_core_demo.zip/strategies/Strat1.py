import pandas as pd
import numpy as np
from talib import EMA
from logging import Logger

from autotrader.strategy import Strategy
from autotrader.brokers.lzdc_broker import Broker
from autotrader.comms.Enum import Direction, Offset, OrderType, CandlesPeriod, PosDirection
from autotrader.brokers.lzdc_order import Order

class Strat1(Strategy):
    def __init__(
        self, parameters: dict, instrument: str, broker: Broker, logger: Logger, *args, **kwargs
    ) -> None:
        self.name = "Strat1"
        self.instrument = instrument
        self.broker = broker
        self.parameters = parameters
        self.logger = logger

        # 从self.parameters中获取计算需要的参数
        self.fast_period = self.parameters.get('param1')
        self.slow_period = self.parameters.get('param2')
        self.macd_period = self.parameters.get('param3')

    def generate_signal(self, dt) -> int:
        """
        生成交易信号
        """
        orders = []

        # # 下多单
        # orders.append(Order(
        #         instrument=self.instrument,
        #         direction=Direction.Long,
        #         offset=Offset.Open,
        #         order_type=OrderType.Market,
        #         size=1
        #     ))
            
        # # 下空单
        # orders.append(Order(
        #         instrument=self.instrument,
        #         direction=Direction.Short,
        #         offset=Offset.Open,
        #         order_type=OrderType.Market,
        #         size=1
        #     ))

        # # 平空单
        # orders.append(Order(
        #             instrument=self.instrument,
        #             direction=Direction.Long,
        #             offset=Offset.Close,
        #             order_type=OrderType.Market,
        #             size=1
        #         ))

        # # 平多单
        # orders.append(Order(
        #             instrument=self.instrument,
        #             direction=Direction.Short,
        #             offset=Offset.Close,
        #             order_type=OrderType.Market,
        #             size=1
        #         ))


        return orders

