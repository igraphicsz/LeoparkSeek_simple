from leopardseek_main.main_virtual_trade import Command

"""
    启动之前，先安装依赖
    pip install http://www.popper-fintech.com/ls/leopardseek_core-1.0.0.tar.gz
    """
if __name__ == "__main__":
    Command().trade();